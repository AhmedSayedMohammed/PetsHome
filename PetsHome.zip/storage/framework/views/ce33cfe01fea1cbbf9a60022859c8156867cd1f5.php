<?php $__env->startSection('content'); ?>


    <div class="row ">
        <div class="col-3">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-6">
            <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <?php echo e(session('status')); ?>

            </div>  
        <?php endif; ?>
          <?php echo $__env->yieldContent('home'); ?>
      
        </div>
          <div class="col-3 float-left d-flex justify-content-end ">
                <?php echo $__env->make('layouts.sidebarright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           </div>
        </div>
   
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\PetsHome\resources\views/home.blade.php ENDPATH**/ ?>