
<div class="side-bar position-fixed border rounded">
     <h3 class="bg-primary p-2 text-dark"> Followers <span class="fa fa-user-friends float-right"></span></h3>
    <ul>
        <div class="text-light">
     <?php $__currentLoopData = Auth::user()->followings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
        <li><a class="btn text-light d-block" href="<?php echo e(route('user.profile.other',$follower->id)); ?>"><img src="<?php echo e($follower->avatar); ?>" style="width: 30px;height: 30px;" class="rounded"> <?php echo e($follower->name); ?></a></li>
   
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>     
    </ul>
</div>

   
<?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\PetsHome\resources\views/layouts/sidebarright.blade.php ENDPATH**/ ?>