<?php $__env->startSection('home'); ?>
<div class="row">
  
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-6">
      <div class="card" style="width: 15rem;">
          <img src="<?php echo e($user->avatar); ?>" class="card-img-top" alt="...">
            <div class="card-body">
            <h5 class="card-title"><?php echo e($user->name); ?></h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModal" >Start</button>
               
              <?php for($i = 0; $i < $user->doctor->rate ; $i++): ?>
                <span class="fa fa-star text-warning float-right"></span>
                <?php endfor; ?>
            </div>
          </div>
           <!-- The Modal -->
 <div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
    
      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Consultation Form</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
      <!-- Modal body -->
      <form action="<?php echo e(route('consultation.room',$user->doctor->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
      <div class="modal-body">
           <div class="container-viewport">         
              <div class="form-group">
                <label for="usr">Your problem:</label>
                <textarea rows="4" cols="50" name="body" class="form-control" required >
                </textarea>
                <br>
                <label>Pet Image</label>
                <input type="file" class="form-control" name="image">
                <input type="number" name="price" value="0" hidden>
                </div>               
           </div>
      </div>
      
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <input type="submit" value="Consult" class="btn btn-primary" >
      </div>       
    </div>
  </form>
  </div>
</div>
    </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\PetsHome\resources\views/sections/consultation/show.blade.php ENDPATH**/ ?>