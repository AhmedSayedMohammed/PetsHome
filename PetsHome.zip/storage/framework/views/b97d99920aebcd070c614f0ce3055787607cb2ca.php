<?php $__env->startSection('home'); ?>


<div class="">
<img src="<?php echo e(Auth::user()->avatar); ?>"  style="width:200px; height:200px; border-width:3px !important;" class="rounded-circle border border-success border-10"  alt="profie">
<h2 class="text-success">Dr/ <?php echo e(Auth::user()->name); ?></h2>

<form action="<?php echo e(route('update.user',Auth::user()->id)); ?>" method="post" enctype="multipart/form-data">
 <?php echo csrf_field(); ?>
  <div class="form-group-light text-light d-flex d-flex-row">
  <input type="file" class="form-control-file" name="avatar" id="" placeholder="" aria-describedby="fileHelpId">
  <button type="submit" class=" btn btn-success">Upload</button>  
</div>
</form>
</div>
<hr color="white">
<div>
  <?php $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
 <div class="card">
   <?php if($consultation->image !=null): ?>
   <img class="card-img-top" src="<?php echo e($consultation->image); ?>" >
   <?php endif; ?>
   <div class="card-body">
     <div class="d-flex d-flex-row">
     <h4 class="card-title text-success">Dr/<?php echo e($consultation->user->name); ?> &nbsp;</h4> <h4 class="card-title"> and <?php echo e($consultation->doctor->user->name); ?>  </h4>
    </div>
     <p class="card-text"><?php echo e($consultation->body); ?></p>
   </div>
 </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\PetsHome\resources\views/users/profile/doctor.blade.php ENDPATH**/ ?>