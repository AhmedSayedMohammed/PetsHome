<?php $__env->startSection('home'); ?>
<h1>User</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\PetsHome\resources\views/users/profile/user.blade.php ENDPATH**/ ?>