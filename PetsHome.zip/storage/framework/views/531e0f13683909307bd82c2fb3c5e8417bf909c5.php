<?php $__env->startSection('home'); ?>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="btn-group">

        <?php if($user->type=='user'): ?>
        <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <h2><?php echo e($user->type); ?> </h2> <?php echo e($user->name); ?>

        </button>
         <div class="dropdown-menu">
          <form  action="<?php echo e(route('make.doctor',$user->id)); ?>" method="POST" >
            <?php echo csrf_field(); ?>
               <button class="dropdown-item" type="submit">Doctor</button>
             </form>    
  
           <form  action="<?php echo e(route('make.admin',$user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
               <button class="dropdown-item" type="submit">Admin</button>
             </form>    
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="#">Block</a>
      </div>
    </div>
        <?php else: ?>
        <?php if($user->type=='doctor'): ?>
        <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <h2><?php echo e($user->type); ?> </h2> <?php echo e($user->name); ?>

                </button>
                <div class="dropdown-menu">
                  <form  action="<?php echo e(route('make.admin',$user->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                       <button class="dropdown-item" type="submit">Admin</button>
                     </form>    
          
                   <form  action="<?php echo e(route('make.user',$user->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                       <button class="dropdown-item" type="submit">User</button>
                     </form>    
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="#">Block</a>
      </div>
    </div>
         <?php else: ?>
         <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <h2><?php echo e($user->type); ?> </h2> <?php echo e($user->name); ?>

                </button>
                <div class="dropdown-menu">
         
         <form  action="<?php echo e(route('make.doctor',$user->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
             <button class="dropdown-item" type="submit">Doctor</button>
           </form>    

         <form  action="<?php echo e(route('make.user',$user->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
             <button class="dropdown-item" type="submit">User</button>
           </form>    
         <div class="dropdown-divider"></div>
         <a class="dropdown-item" href="#">Block</a>
       </div>
       </div>
         <?php endif; ?>
        <?php endif; ?>
        
     

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\PetsHome\resources\views/users/profile/admin.blade.php ENDPATH**/ ?>