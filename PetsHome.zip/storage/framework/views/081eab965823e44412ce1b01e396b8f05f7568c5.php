
<div class="side-bar position-fixed border rounded">
     <h3 class="bg-primary p-2 text-dark"> Sections <span class="fa fa-align-justify float-right"></span></h3>
    <ul>
            <?php if(Auth::user()->type!='doctor'): ?>
            <li>
            <a class="btn text-light d-block"  href="<?php echo e(route('consultation')); ?>">Consultation <span class="glyphicon glyphicon-phone-alt pull-right"></span></a>
            </li>
            <?php endif; ?>
            <li>
            <a class="btn text-light d-block"  href="<?php echo e(route('adoption.get')); ?>" class="active">Adoption<span class="glyphicon glyphicon-heart pull-right"></span></a>
            </li>
            <li>
            <a class="btn text-light d-block"  href="<?php echo e(route('section.street.pets.get')); ?>">Street Pets <span class="glyphicon glyphicon-road pull-right"></span></a>
            </li>
    </ul>

</div>

   
<?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\PetsHome\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>