<?php $__env->startSection('home'); ?>
<div class="d-flex">
<div >
  <img src="<?php echo e($other->avatar); ?>"  style="width:200px; height:200px;" class="rounded-circle border border-dark border-2-improtant"  alt="profile">
  <h2 class="text-light">Dr/ <?php echo e($other->name); ?></h2>
</div>
 <div class="float-right align-self-center text-light">
 <h4>Follow  &nbsp;&nbsp; | <span class="fa fa-user"></span>  <?php echo e($other->followings->count()); ?></h4>
 <h4>Follower | <span class="fa fa-user-friends"></span> <?php echo e($other->followers->count()); ?></h4>
    <h4>Posts  &nbsp; &nbsp; &nbsp; | <span class="fa fa-book"></span>  <?php echo e($other->posts->count()); ?></h4>
</div>
</div>
<follow :other="<?php echo e($other); ?>" :user="<?php echo e(Auth::user()); ?>" :followed="<?php echo e($followed); ?>"></follow>
<hr class="bg-light">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\PetsHome\resources\views/users/profile/other.blade.php ENDPATH**/ ?>