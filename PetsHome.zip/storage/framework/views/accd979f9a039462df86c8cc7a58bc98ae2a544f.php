<?php $__env->startSection('home'); ?>
<posts :user="<?php echo e(Auth::user()); ?>"> </posts>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\PetsHome\resources\views/manage/post/show.blade.php ENDPATH**/ ?>