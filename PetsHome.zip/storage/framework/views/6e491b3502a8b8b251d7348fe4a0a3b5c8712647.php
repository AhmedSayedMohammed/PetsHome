<?php $__env->startSection('home'); ?>
   <consultation :consultation_id="<?php echo e($consultation_id); ?>" :user="<?php echo e(Auth::user()); ?>" ></consultation>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\PetsHome\resources\views/sections/consultation/room.blade.php ENDPATH**/ ?>