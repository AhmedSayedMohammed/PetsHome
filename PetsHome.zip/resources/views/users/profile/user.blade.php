@extends('home')
@section('home')
<h1>User</h1>
@endsection